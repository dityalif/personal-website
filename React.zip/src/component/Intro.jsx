const Intro = () => {
  return (
    <div className="my-20">
        <h1 className="text-center font-bold text-4xl py-5">Get to Know Me</h1>
        <div className="flex place-content-center">

            <div className="w-1/4 m-8 bg-[#008891] text-white p-6 rounded-3xl shadow-xl bg-gradient-to-r from-[#008891] to-[#00587A] transition duration-200 hover:scale-105">
                <h2 className="text-center text-2xl font-semibold pb-3">About Me</h2>
                <p className="text-justify">
                    I am a Computer Engineering student at the University of Indonesia with a strong passion for technology, particularly in the software domains. 
                    My previous experience as Vice President of my high school's student council helped me develop my leadership and organizational skills. 
                    I am deeply committed in advancing my knowledge and skills in the world of technology. With a focus on software development and a keen interest in data analysis
                </p>
            </div>

            <div className="w-1/4 m-8 bg-[#008891] text-white p-6 rounded-3xl shadow-xl bg-gradient-to-r from-[#008891] to-[#00587A] transition duration-200 hover:scale-105">
                <h2 className="text-center text-2xl font-semibold pb-3">Education</h2>
            </div>

            <div className="w-1/4 m-8 bg-[#008891] text-white p-6 rounded-3xl shadow-xl bg-gradient-to-r from-[#008891] to-[#00587A] transition duration-200 hover:scale-105">
                <h2 className="text-center text-2xl font-semibold pb-3">Organization</h2>
            </div>

        </div>
    </div>
  )
}

export default Intro